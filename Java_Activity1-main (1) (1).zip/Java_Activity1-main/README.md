![q1](https://user-images.githubusercontent.com/98822072/155872496-84d58461-9144-4782-b5c0-6563488cb504.png)
# Java_Activity1
